#include <stdio.h>
#include <stdlib.h>
#include <stdint.h> /* SIZE_MAX */
#include <string.h>
#include <math.h>

void select_sort(int A[], size_t n)
{
	int i, a, j;
	for (i = 0; i < n; ++i)
    {
        for (j = i + 1; j < n; ++j)
        {
            if (A[i] > A[j])
            {
                a =  A[i];
                A[i] = A[j];
                A[j] = a;
            }
        }
    }
}
	//Your code goes here! SORTING 


int read_array(FILE *fp, int *p_A[])
{
	int number, count;
	number = 0;
	int i=0;

	//&((*p_A)[number])
	while(fscanf(fp,"%d", &count) != -1){
		number++;
	}


	rewind(fp);
	int *A =malloc(number*(sizeof(int)));
	
	while(i<number)
	{
		fscanf(fp, "%d", &A[i]);
		i++;
	}

    *p_A = A;

	return count;
}


void print_array(const int *A, int n)
{
	//Your code goes here! PRINTING THE ARRAY
	int count = 0;
	fprintf(stderr, "printing array n: %d\n", n);
	while(count < n){
		fprintf(stderr, "%d, ", A[count]);
		count++;
	}
	fprintf(stderr, "\n\n\n\n\n");

}

double mean_array(const int *A, int n)
{
	int i;
	double avg, sum = 0.0;
	
	for(i = 0;i < n ;i++){
		sum+=A[i];
	}
	avg=(sum/n);
	return avg;

}

double median_array(const int *A, int n)
{
	double median;
	if(n%2==0){
		median= (A[n/2] + A[n/2 + 1])/2.0;
	}
	else
		median = A[n/2 + 1];
	
	return median;

}
