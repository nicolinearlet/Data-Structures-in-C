#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

#define MAX_KEY_LEN (32)
#define MAX_VALUE_LEN (32)
struct tree_data {
	char key[MAX_KEY_LEN];
	char value[MAX_VALUE_LEN];
};

struct tree_node {
	struct tree_data data;
	struct tree_node *left;
	struct tree_node *right;
};


void tree_print(struct tree_node *node)
{
	if(node == NULL){
		return;
	}
	tree_print(node->left);
	printf("%s %s \n", node->data.key, node->data.value);
	tree_print(node->right);
	/* Iterate through the tree with an in-order traversal and
	 * print each every key and value per line.
	 */
}

struct tree_node *tree_find(struct tree_node *root, const char *key){
	
	struct tree_node* n = root;
	
	while(n != NULL){
		
		if( strcmp(n->data.key, key)==0) return n;
		
		if(strcmp(n->data.key, key) > 0) n = n->left;
	
		else if (strcmp(n->data.key, key) < 0) n = n->right;
	}
	
	return NULL;
	
	/* Search through the tree for a node with the given key.
	 * Return a pointer to the node if found, and NULL if not
	 * found.
	 */
}


int tree_insert(struct tree_node **p_root, struct tree_data data)
{
	struct tree_node *n = *p_root;
	if(n== NULL){
		n = malloc(sizeof(struct tree_node));
		n->data = data;
		n->left = n->right = NULL;
		*p_root = n;
		return 0;
	} 
	if(strcmp(n->data.key, data.key)==0){
		return -1;
	}
	if(strcmp(n->data.key, data.key) < 0){
		return tree_insert(&((*p_root) -> right), data);
	}
	else //if (strcmp((*p_root)->data.key, data.key) > 0)
	{
		return tree_insert(&((*p_root)-> left), data);
	}
}
	
	/* Insert a piece of data into the BST with
	 * the given root.
	 * Return 0 if successful, -1 if it exists already, or if
	 * there is an allocation failure.
	 */
	 


void tree_destroy(struct tree_node *root)
{
	struct tree_node* n = root;
	
  	if(n != NULL){
  		free(n);
  		tree_destroy(n->left);
  		tree_destroy(n->right);
  	}	
	/* Traverse the tree from the root and safely dellocate every node. */
}


int main(int argc, char *argv[])
{
	if (argc < 2) {
		fprintf(stderr, "Usage: dict data_file.txt [lookup_commands.txt]\n"
			         "Note: There is no sorted argument.\n");
		return 1;
	}

	FILE *fp_data = fopen(argv[1], "rb");
	if (fp_data == NULL) {
		fprintf(stderr, "Error opening %s\n", argv[1]);
		return 1;
	}

	FILE *fp_lookup = NULL;
	if (argc > 2) {
		fp_lookup = fopen(argv[2], "rb");
		if (fp_lookup == NULL) {
			fprintf(stderr, "Error opening lookups file %s\n", argv[2]);
			return 1;
		}
	}

	struct tree_data d;
	struct tree_node *root = NULL;

	while (!feof(fp_data) && !ferror(fp_data)) {
		if (fscanf(fp_data, "%s %s", d.key, d.value) != 2)
			continue;
		
	//	printf("Insert %s %s in sorted order\n", d.key, d.value);

		if (tree_insert(&root, d) < 0) {
			fprintf(stderr, "Error while inserting into tree: %s\n", strerror(errno));
		}

	//	tree_print(root);
	}


	char lookup_key[MAX_KEY_LEN];
	struct tree_node *lookup_node;
	int found_count = 0;
	while (fp_lookup && !feof(fp_lookup) && !ferror(fp_lookup)) {
		if (fscanf(fp_lookup, "%s", lookup_key) != 1)
			continue;

		if ((lookup_node = tree_find(root, lookup_key)) != NULL) {
		//	printf("Found: %s %s\n", lookup_node->data.key, lookup_node->data.value);
		found_count ++;
		}
		else {
		//	printf("Failed to find: %s\n", lookup_key);
		}
	}
	printf("Found count is %d\n", found_count);
	
	tree_destroy(root);
	
	fclose(fp_data);

	if (fp_lookup) {
		fclose(fp_lookup);
	}

	return 0;
}
	
